#include <iostream>
using namesapce std;
int main()
{
int a,b;
float f;
char c;
a=b;
f=a;
return 0;
}   
