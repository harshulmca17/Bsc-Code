//its taking multi line comment only once

/* its a multi line comment */*/

int main()
{
	int A=2;
	if(A<54)
	{ cout<<"hello"; }
}
