
echo -e "\nEnter filename: "
read fname

if test -f $fname
then
echo "Removing spaces";
else
echo "The file doesn't exist.    Exiting...";
exit
fi

cat $fname | tr -t "\t" " " | tr -s "\n" | tr -s " " > temp.txt

rm $fname
mv temp.txt $fname	

echo -e "\nFile after removing spaces :- "
cat $fname 
