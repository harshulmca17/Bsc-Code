
compare()
{
	echo ""	
	cmp $fname1 $fname2
	val=`echo $?`

	if [ $val -eq 0 ]	#the files are same
	then
	    echo -e "\nThe files are same."
	    rm $fname2
            echo -e "\n$fname2 has been deleted."
	else
	echo -e "\nThe files are different. No action required."	
	fi

	echo "-------------------------------------------------"
}


echo "-------------------------------------------------"
echo -e "Enter first filename :"
read fname1

if test -e $fname1
then
	echo -e "\nEnter second filename :"
	read fname2
	
	if test -e $fname2
	then
	   compare
	else
	   echo -e "\nThis file does not exist. Please try again. "
	fi	
else
echo -e "\nThis file does not exist. Please try again. "
fi
