menu()
{
	echo "**************************************************"
	echo -e "->Actions to be performed on a file :"
	echo "--------------------------------------------------" 
	echo -e "1.Display the file."
	echo -e "2.Display the permissions of the file."
	echo -e "3.Find a pattern in the file- ignoring case."
	echo -e "4.Find a pattern in the file- case sensitive."
	echo -e "5.Replace all letters 'e' by 'a'"
	echo "**************************************************"
	echo -e "Enter your choice: "
	read ch
	choice
}

choice()
{
	case $ch in
	
	1) echo "                                                  "	
	   echo "Your file is-"
	   echo "--------------------------------------------------" 
	   cat $fname
	   echo "--------------------------------------------------" ;;
	   
	2) echo -e "\nThe permissions of the file are-"
	   echo "--------------------------------------------------" 
	   ls -l $fname | cut -d " " -f1
	   echo "--------------------------------------------------";;
	
	3) echo -e "\nEnter the pattern to be searched-"
	   read patt
	   echo "                                                  "
	   echo "--------------------------------------------------"
	   grep -i $patt $fname
	   echo "--------------------------------------------------" ;;
	
	4) echo -e "\nEnter the pattern to be searched-"
           read patt
	   echo "                                                  "
	   echo "--------------------------------------------------"
	   grep $patt $fname
	   echo "--------------------------------------------------";;
	
	5) echo "                                                  "	
	   echo "Contents of file on modification-"
	   echo "--------------------------------------------------" 
	   cat $fname | tr 'e' 'a'
	   echo "--------------------------------------------------" ;;
	
	*) echo -e "\nPlease enter a valid choice."
	
	esac

	continueYN
}

continueYN()
{
	echo "                                                  "
        echo -e -n "\nDo you wish to continue? : "
	read c
	echo "                                                  "
        
	if [ $c = 'y' ]
	then
	menu
	elif [ $c = 'Y' ]
	then
	menu
	else
	exit
	fi
}

echo "                                                  "
echo -e "Enter a filename :"
read fname
echo "                                                  "
        
if test -e $fname
then
menu
else
echo -e "\nInvalid file name. Please try again. "
fi

