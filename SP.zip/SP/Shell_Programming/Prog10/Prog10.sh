
merge_sort()
{
	echo "-------------------------------------------------"	
	sort -m $file1 $file2 $file3 > merge
	echo "Merged and Sorted file :-"
	echo "-------------------------------------------------"
	sort merge | more
	rm merge
}




echo "-------------------------------------------------"
echo -e "Enter first filename :"
read file1

if test -e $file1
then
	echo -e "\nEnter second filename :"
	read file2
	
	if test -e $file2
	then
		echo -e "\nEnter third filename :"
		read file3
	
		if test -e $file3
		then
		  merge_sort
		else
		echo -e "\nThis file does not exist. Please try again. "
		fi	
	else
	echo -e "\nThis file does not exist. Please try again. "
	fi	
else
echo -e "\nThis file does not exist. Please try again. "
fi
echo "-------------------------------------------------"
