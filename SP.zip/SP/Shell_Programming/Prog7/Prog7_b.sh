
users | tr " " "\n" | sort | uniq > temp1.txt
cat temp1.txt | tr "\n" " " > temp2.txt

((count=`cat temp1.txt | wc -w`))

echo -e "\nThe Distinct users are : "
cat temp1.txt

for((i=1;i<=count;i++))
do
	patt=`cat temp2.txt | cut -d " " -f$i`
	unique_count=`users | tr " " "\n" | grep -cw $patt`
	echo -e "\nThe User $patt is logged in $unique_count times.\n"
done
