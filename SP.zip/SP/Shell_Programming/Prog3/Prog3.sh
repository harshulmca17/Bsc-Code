printMonthYear()
{

	if [ $argc -eq 1 ]
	then
	year=`date | cut -d " " -f6`
	else
	year=$arg2
	fi
	
	case $arg1 in
	jan*|Jan*|JAN*) cal 01 $year ;;
	feb*|Feb*|FEB*) cal 02 $year ;;
	mar*|Mar*|MAR*) cal 03 $year ;;
	apr*|Apr*|APR*) cal 04 $year ;;
	may*|May*|MAY*) cal 05 $year ;;
	jun*|Jun*|JUN*) cal 06 $year ;;
	jul*|Jul*|JUL*) cal 07 $year ;;
	aug*|Aug*|AUG*) cal 08 $year ;;
	sep*|Sep*|SEP*) cal 09 $year ;;
	oct*|Oct*|OCT*) cal 10 $year ;;
	nov*|Nov*|NOV*) cal 11 $year ;;
	dec*|Dec*|DEC*) cal 12 $year ;;
	*) cal $arg1
	esac
}

	argc=$#
	arg1=$1
	arg2=$2

	if [ $argc -gt 2 ]
	then
	echo -e "\nMaximum no of arguments are 2\n";
	exit
	fi

	if [ $argc -eq 0 ]
	then
	cal
	elif [ $argc -ge 1 ]
	then
	printMonthYear	
	fi
