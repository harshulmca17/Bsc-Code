rev=" "
	
for i in $*
do
  rev="$i $rev"
done

echo $rev
