	menu()
{
	echo "**************************************************"
	echo -e "->Actions to be performed on a file :"
	echo "--------------------------------------------------"
	echo -e "1.Display the file."
	echo -e "2.Display last n lines of the file."
	echo -e "3.Sort the file in ascending order."
	echo -e "4.Sort the file in descending order."
	echo "**************************************************"
	echo -e "Enter your choice: "
	read ch
	choice
}

choice()
{
	case $ch in
	
	1) echo "                                                  "	
	   echo "Your file is-"
	   echo "--------------------------------------------------" 
	   cat $fname
	   echo "--------------------------------------------------" ;;
	   
	2) echo -ne "\nEnter n no. of lines to be printed : "
	   read n
	   echo "--------------------------------------------------" 
	   tail -$n $fname
	   echo "--------------------------------------------------";;
	
	3) echo -e "\nContents of file in ascending order-"
	   echo "                                                  "
	   echo "--------------------------------------------------"
	   sort $fname
	   echo "--------------------------------------------------" ;;
	
	4) echo -e "\nContents of file in descending order-"
	   echo "                                                  "
	   echo "--------------------------------------------------"
	   sort -r $fname
	   echo "--------------------------------------------------";;
	
	*) echo -e "\nPlease enter a valid choice."
	
	esac

	continueYN
}

continueYN()
{
	echo "                                                  "
        echo -e -n "\nDo you wish to continue? : "
	read c
	echo "                                                  "
        
	if [ $c = 'y' ]
	then
	menu
	elif [ $c = 'Y' ]
	then
	menu
	else
	exit
	fi
}

echo "                                                  "
echo -e "Enter a filename :"
read fname
echo "                                                  "
        
if test -e $fname
then
menu
else
echo -e "\nInvalid file name. Please try again. "
fi

