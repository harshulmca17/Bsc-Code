echo $* |
awk 'BEGIN{ FS="-"; OFS="/" }
{
  mm=$1
  dd=$2
  yy=$3 
       
        if(length($0)!=8)
        { 
            print"INVALID DATE\n"
            exit
        }
       
        if(yy<1||y>99)
        {
            printf"INVALID DATE\n"
            exit
        }
        
        if(mm<1 || mm>12)
        {
            printf"INVALID DATE\n"
            exit
        }
        
        if(dd<1 || dd>31)
        { 
            printf"INVALID DATE\n"
            exit
        }

        print dd,mm,yy;
}'
